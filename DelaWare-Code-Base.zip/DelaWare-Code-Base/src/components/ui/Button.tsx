import type { ButtonHTMLAttributes } from 'react'

type Variant = 'primary' | 'ghost'

const base =
  'inline-flex items-center justify-center rounded-brand px-5 py-2.5 ' +
  'font-medium transition-colors focus-visible:outline-none ' +
  'focus-visible:ring-2 focus-visible:ring-brand-blue disabled:opacity-50'

const variants: Record<Variant, string> = {
  primary: 'bg-brand-blue text-white hover:bg-[#0039cc]',
  ghost: 'bg-transparent text-brand-ink hover:bg-black/5',
}

export function Button({
  variant = 'primary',
  className = '',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return <button className={`${base} ${variants[variant]} ${className}`} {...props} />
}
