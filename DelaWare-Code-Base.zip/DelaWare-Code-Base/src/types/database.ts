// Minimal hand-written types matching migration 0001. Once your schema
// grows, replace this file with generated types:
//   npx supabase gen types typescript --linked > src/types/database.ts
export type AppRole = 'admin' | 'staff' | 'member'

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          full_name: string | null
          phone: string | null
          avatar_url: string | null
          created_at: string
        }
        Insert: { id: string; full_name?: string | null; phone?: string | null }
        Update: { full_name?: string | null; phone?: string | null; avatar_url?: string | null }
        Relationships: []
      }
      user_roles: {
        Row: { id: string; user_id: string; role: AppRole }
        Insert: { user_id: string; role: AppRole }
        Update: { role?: AppRole }
        Relationships: []
      }
    }
    Views: { [_ in never]: never }
    Functions: { [_ in never]: never }
    Enums: { app_role: AppRole }
    CompositeTypes: { [_ in never]: never }
  }
}
