import { useAuth } from '@/providers/AuthProvider'
import { useRole } from '@/hooks/useRole'
import { Button } from '@/components/ui/Button'
import { Link } from 'react-router-dom'

export function Dashboard() {
  const { user, signOut } = useAuth()
  const { isAdmin } = useRole()

  return (
    <main className="mx-auto max-w-2xl px-6 py-10">
      <h1 className="font-display text-3xl text-brand-ink">Dashboard</h1>
      <p className="mt-2 text-[var(--color-muted)]">Signed in as {user?.email}</p>
      <div className="mt-6 flex gap-3">
        {isAdmin && (
          <Link to="/admin">
            <Button>Admin area</Button>
          </Link>
        )}
        <Button variant="ghost" onClick={signOut}>
          Sign out
        </Button>
      </div>
    </main>
  )
}
