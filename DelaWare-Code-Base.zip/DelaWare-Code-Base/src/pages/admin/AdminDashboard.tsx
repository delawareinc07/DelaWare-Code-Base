import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/Button'

// Reached only after ProtectedRoute confirms an 'admin' role, so this
// component never has to guard itself or risk its own redirect loop.
export function AdminDashboard() {
  return (
    <main className="mx-auto max-w-2xl px-6 py-10">
      <p className="font-display text-sm uppercase tracking-wide text-brand-green">
        Admin
      </p>
      <h1 className="font-display text-3xl text-brand-ink">Control panel</h1>
      <p className="mt-2 text-[var(--color-muted)]">
        Add members, manage roles, and wire up your project tables here.
      </p>
      <Link to="/" className="mt-6 inline-block">
        <Button variant="ghost">Back to dashboard</Button>
      </Link>
    </main>
  )
}
