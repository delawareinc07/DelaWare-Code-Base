-- Delaware Inc. starter: roles, profiles, and row level security
-- This migration encodes the role pattern we reuse on every build.
-- The important detail: roles live in their OWN table, and policies
-- check them through a SECURITY DEFINER function. Checking roles by
-- querying the same table a policy protects causes infinite recursion
-- in Postgres RLS. The function below is how we avoid that for good.

-- 1. App role enum. Extend per project (e.g. add 'agent', 'auditor').
create type public.app_role as enum ('admin', 'staff', 'member');

-- 2. Profiles. One row per auth user, created automatically on signup.
create table public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text,
  phone       text,
  avatar_url  text,
  created_at  timestamptz not null default now()
);

-- 3. Roles live separately from profiles so a user can hold several,
--    and so role checks never touch profile read policies.
create table public.user_roles (
  id       uuid primary key default gen_random_uuid(),
  user_id  uuid not null references auth.users (id) on delete cascade,
  role     public.app_role not null,
  unique (user_id, role)
);

-- 4. THE function. SECURITY DEFINER means it runs with the definer's
--    rights and bypasses RLS on user_roles, so a policy can call it
--    without recursing back into a policy on the same table.
create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role = _role
  );
$$;

-- Convenience wrapper for the current request's user.
create or replace function public.current_user_has_role(_role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.has_role(auth.uid(), _role);
$$;

-- 5. Auto-create a profile and a default 'member' role on signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data ->> 'full_name');

  insert into public.user_roles (user_id, role)
  values (new.id, 'member');

  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- 6. Enable RLS. Nothing is readable until a policy says so.
alter table public.profiles   enable row level security;
alter table public.user_roles enable row level security;

-- Profiles: a user reads and edits their own; admins see all.
create policy "read own profile"
  on public.profiles for select
  using (auth.uid() = id or public.current_user_has_role('admin'));

create policy "update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- User roles: a user may read their own roles (so the client can
-- resolve them), but only admins may grant or revoke.
create policy "read own roles"
  on public.user_roles for select
  using (auth.uid() = user_id or public.current_user_has_role('admin'));

create policy "admins manage roles"
  on public.user_roles for all
  using (public.current_user_has_role('admin'))
  with check (public.current_user_has_role('admin'));
