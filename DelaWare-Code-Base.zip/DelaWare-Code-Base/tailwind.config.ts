import type { Config } from 'tailwindcss'

// Delaware Inc. brand tokens. These are the source of truth; the same
// values are mirrored as CSS variables in src/index.css for use outside
// Tailwind (inline styles, third-party widgets, charts).
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#0046FF', // Primary Blue
          blue: '#0046FF',
          green: '#00D084', // Accent Green
          ink: '#0C1B33', // Ink Navy
        },
      },
      fontFamily: {
        // Space Grotesk for display, Inter for body. Loaded in index.html.
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        brand: '12px',
      },
    },
  },
  plugins: [],
} satisfies Config
